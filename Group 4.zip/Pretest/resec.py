import tkinter as tk
import math

from tkinter import messagebox


def calculate_unknown_coordinate():
    try:
        # Get the known coordinates of the two points
        x1 = float(entry_x1.get())
        y1 = float(entry_y1.get())
        
        x2 = float(entry_x2.get())
        y2 = float(entry_y2.get())
        
        # Get the bearings
        bearing_Stn1 = float(entry_bearing_Stn1.get())
        bearing_Stn2 = float(entry_bearing_Stn2.get())
        # Calculate the different in bearings
        bearing_degrees = bearing_Stn1- bearing_Stn2
        
        # Convert the bearing from degrees to radians
        bearing_radians = math.radians(bearing_degrees)
        bearing_radians1 = math.radians(bearing_Stn1)
        bearing_radians2 = math.radians(bearing_Stn2)
        
        # Calculate the difference in x and y coordinates
        dx = x2 - x1
        dy = y2 - y1
        
        # Calculate the distance from point 1 to the unknown 
        distance1_Unknown = (dy * math.sin(bearing_radians2) - dx * math.cos(bearing_radians2)) / math.sin(bearing_radians)
        distance2_Unknown = (dy * math.sin(bearing_radians1) - dx * math.cos(bearing_radians2)) / math.sin(bearing_radians)
        # Calculate the x and y coordinates of the unknown point
        x_unknown = x1 + distance1_Unknown * math.cos(bearing_radians)
        y_unknown = y1 + distance2_Unknown * math.sin(bearing_radians)
        
        # Display the result in a messagebox
        New_Coordinates = f"The unknown coordinate is:\n\nY: {y_unknown}\nX: {x_unknown}"
        messagebox.showinfo("Result", New_Coordinates)
        
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numeric values.")


# Create the GUI window
window = tk.Tk()
window.title("Triangulation Resection")
window.geometry("1000x500+0+0")

#Frames
Frame_Top = tk.Frame()
Frame_Top.place(relx=0, rely=0.003, relheight=1, relwidth=1)
Frame_Top.configure(relief='groove')
Frame_Top.configure(borderwidth="8")
Frame_Top.configure(relief="groove")
Frame_Top.configure(background="#d9d9d8")

Label_Name = tk.Label()
Label_Name.place(relx=0.0002, rely=0.01, relheight=0.08, width=1353)
Label_Name.configure(background="#000000")
Label_Name.configure(borderwidth="4")
Label_Name.configure(disabledforeground="#a3a3a3")
Label_Name.configure(font="-family {OCR A Std} -size 25 -weight bold")
Label_Name.configure(foreground="#ffffff")
Label_Name.configure(text='''RESECTION METHOD''')

label_y1 = tk.Label(window, text="Y1")
label_y1.pack()
label_y1.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_y1.configure(borderwidth="8")
label_y1.configure(disabledforeground='#a3a3a3')
label_y1.place(relx=0.12, rely=0.20, relheight=0.06, width=25,)
entry_y1 = tk.Entry(window)
entry_y1.pack()
entry_y1.place(relx=0.15, rely=0.20, height=35, relwidth=0.2, bordermode='ignore')
entry_y1.configure(background="white")
entry_y1.configure(disabledforeground="#a3a3a3")
entry_y1.configure(font="-family {Segoe UI} -size 14")
entry_y1.configure(foreground="#000000")
entry_y1.configure(insertbackground="black")
entry_y1.configure(borderwidth="5")

label_x1 = tk.Label(window, text="X1")
label_x1.pack()
label_x1.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_x1.configure(borderwidth="8")
label_x1.configure(disabledforeground='#a3a3a3')
label_x1.place(relx=0.12, rely=0.28, relheight=0.06, width=25,)
entry_x1 = tk.Entry(window)
entry_x1.pack()
entry_x1.place(relx=0.15, rely=0.28, height=35, relwidth=0.2, bordermode='ignore')
entry_x1.configure(background="white")
entry_x1.configure(disabledforeground="#a3a3a3")
entry_x1.configure(font="-family {Segoe UI} -size 14")
entry_x1.configure(foreground="#000000")
entry_x1.configure(insertbackground="black")
entry_x1.configure(borderwidth="5")

label_y2 = tk.Label(window, text="Y2")
label_y2.pack()
label_y2.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_y2.configure(borderwidth="8")
label_y2.configure(disabledforeground='#a3a3a3')
label_y2.place(relx=0.12, rely=0.36, relheight=0.06, width=25,)
entry_y2 = tk.Entry(window)
entry_y2.pack()
entry_y2.place(relx=0.15, rely=0.36, height=35, relwidth=0.2, bordermode='ignore')
entry_y2.configure(background="white")
entry_y2.configure(disabledforeground="#a3a3a3")
entry_y2.configure(font="-family {Segoe UI} -size 14")
entry_y2.configure(foreground="#000000")
entry_y2.configure(insertbackground="black")
entry_y2.configure(borderwidth="5")

label_x2 = tk.Label(window, text="X2:")
label_x2.pack()
label_x2.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_x2.configure(borderwidth="8")
label_x2.configure(disabledforeground='#a3a3a3')
label_x2.place(relx=0.12, rely=0.44, relheight=0.06, width=25,)
entry_x2 = tk.Entry(window)
entry_x2.pack()
entry_x2.place(relx=0.15, rely=0.44, height=35, relwidth=0.2, bordermode='ignore')
entry_x2.configure(background="white")
entry_x2.configure(disabledforeground="#a3a3a3")
entry_x2.configure(font="-family {Segoe UI} -size 14")
entry_x2.configure(foreground="#000000")
entry_x2.configure(insertbackground="black")
entry_x2.configure(borderwidth="5")

label_bearing_Stn1 = tk.Label(window, text="Bearing_Stn1 (degrees)")
label_bearing_Stn1.pack()
label_bearing_Stn1.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_bearing_Stn1.configure(borderwidth="8")
label_bearing_Stn1.configure(disabledforeground='#a3a3a3')
label_bearing_Stn1.place(relx=0.14, rely=0.52, relheight=0.06, width=220)
entry_bearing_Stn1 = tk.Entry(window)
entry_bearing_Stn1.pack()
entry_bearing_Stn1.place(relx=0.15, rely=0.60, height=35, relwidth=0.2, bordermode='ignore')
entry_bearing_Stn1.configure(background="white")
entry_bearing_Stn1.configure(disabledforeground="#a3a3a3")
entry_bearing_Stn1.configure(font="-family {Segoe UI} -size 14")
entry_bearing_Stn1.configure(foreground="#000000")
entry_bearing_Stn1.configure(insertbackground="black")
entry_bearing_Stn1.configure(borderwidth="5")

label_bearing_Stn2 = tk.Label(window, text="Bearing_Stn2 (degrees)")
label_bearing_Stn2.pack()
label_bearing_Stn2.configure(font="-family {Segoe UI} -size 14 -weight bold")
label_bearing_Stn2.configure(borderwidth="8")
label_bearing_Stn2.configure(disabledforeground='#a3a3a3')
label_bearing_Stn2.place(relx=0.14, rely=0.68, relheight=0.06, width=220,)
entry_bearing_Stn2 = tk.Entry(window)
entry_bearing_Stn2.pack()
entry_bearing_Stn2.place(relx=0.15, rely=0.76, height=35, relwidth=0.2, bordermode='ignore')
entry_bearing_Stn2.configure(background="white")
entry_bearing_Stn2.configure(disabledforeground="#a3a3a3")
entry_bearing_Stn2.configure(font="-family {Segoe UI} -size 14")
entry_bearing_Stn2.configure(foreground="#000000")
entry_bearing_Stn2.configure(insertbackground="black")
entry_bearing_Stn2.configure(borderwidth="5")

# Create a button to calculate the unknown coordinate
calculate_button = tk.Button(window, text="Calculate", command=calculate_unknown_coordinate)
calculate_button.pack()
calculate_button.configure(font="-family {Segoe UI} -size 14 -weight bold")
calculate_button.configure(borderwidth="8")
calculate_button.configure(disabledforeground='#a3a3a3')
calculate_button.place(relx=0.14, rely=0.84, height=35, width=220,)
calculate_button.configure(activebackground="#ececec")
calculate_button.configure(activeforeground="#000000")
calculate_button.configure(background="#f2f2f2")
calculate_button.configure(foreground="#000000")
calculate_button.configure(highlightbackground="#d9d9d9")
calculate_button.configure(highlightcolor="black")
calculate_button.configure(pady="0")


# Run the GUI window
window.mainloop()
